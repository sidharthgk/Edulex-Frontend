import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Trophy, Flame, BarChart3, Book, Code2, GitCompare, Play, Download, Copy } from 'lucide-react';

const StatCard = ({ icon: Icon, title, value }: { icon: any, title: string, value: string }) => (
  <div className="glass-panel p-6">
    <div className="flex items-center space-x-4">
      <Icon className="h-8 w-8 text-amber-500" />
      <div>
        <h3 className="text-sm text-gray-400">{title}</h3>
        <p className="text-2xl font-bold">{value}</p>
      </div>
    </div>
  </div>
);

const CodeConverter = () => {
  const [fromLanguage, setFromLanguage] = useState('javascript');
  const [toLanguage, setToLanguage] = useState('python');
  const [sourceCode, setSourceCode] = useState('');
  const [convertedCode, setConvertedCode] = useState('');

  const handleConvert = () => {
    // Placeholder conversion logic
    if (fromLanguage === 'javascript' && toLanguage === 'python') {
      const converted = sourceCode
        .replace('const ', '')
        .replace('let ', '')
        .replace('var ', '')
        .replace(';', '')
        .replace('function ', 'def ')
        .replace('===', '==')
        .replace('{', ':')
        .replace('}', '');
      setConvertedCode(converted);
    }
  };

  const languages = [
    { value: 'javascript', label: 'JavaScript' },
    { value: 'python', label: 'Python' },
    { value: 'java', label: 'Java' },
    { value: 'cpp', label: 'C++' },
    { value: 'rust', label: 'Rust' },
  ];

  return (
    <div className="glass-panel p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold">Code Converter</h2>
        <div className="flex space-x-4">
          <select
            value={fromLanguage}
            onChange={(e) => setFromLanguage(e.target.value)}
            className="input-field bg-black/50"
          >
            {languages.map((lang) => (
              <option key={lang.value} value={lang.value}>{lang.label}</option>
            ))}
          </select>
          <GitCompare className="h-6 w-6 text-amber-500" />
          <select
            value={toLanguage}
            onChange={(e) => setToLanguage(e.target.value)}
            className="input-field bg-black/50"
          >
            {languages.map((lang) => (
              <option key={lang.value} value={lang.value}>{lang.label}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium">Source Code</label>
            <button
              onClick={() => setSourceCode('')}
              className="text-sm text-amber-500 hover:text-amber-400"
            >
              Clear
            </button>
          </div>
          <textarea
            value={sourceCode}
            onChange={(e) => setSourceCode(e.target.value)}
            className="input-field h-64 font-mono"
            placeholder="Enter your code here..."
          />
        </div>
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium">Converted Code</label>
            <div className="flex space-x-2">
              <button
                onClick={() => navigator.clipboard.writeText(convertedCode)}
                className="text-sm text-amber-500 hover:text-amber-400"
              >
                <Copy className="h-4 w-4" />
              </button>
              <button
                onClick={() => {
                  const blob = new Blob([convertedCode], { type: 'text/plain' });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = `converted.${toLanguage}`;
                  a.click();
                }}
                className="text-sm text-amber-500 hover:text-amber-400"
              >
                <Download className="h-4 w-4" />
              </button>
            </div>
          </div>
          <textarea
            value={convertedCode}
            readOnly
            className="input-field h-64 font-mono"
            placeholder="Converted code will appear here..."
          />
        </div>
      </div>

      <div className="flex justify-center mt-6">
        <button
          onClick={handleConvert}
          className="btn-primary flex items-center space-x-2"
        >
          <Play className="h-4 w-4" />
          <span>Convert Code</span>
        </button>
      </div>
    </div>
  );
};

const Dashboard = () => {
  return (
    <div className="min-h-screen pt-20 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid gap-8"
        >
          {/* Header */}
          <div className="glass-panel p-8">
            <div className="flex items-center space-x-4 mb-6">
              <div className="h-16 w-16 rounded-full bg-gradient-to-r from-amber-500 to-yellow-500 flex items-center justify-center">
                <Code2 className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold">Welcome back, Developer!</h1>
                <p className="text-gray-400">Continue your learning journey</p>
              </div>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard icon={Trophy} title="Total Points" value="2,450" />
            <StatCard icon={Flame} title="Current Streak" value="7 days" />
            <StatCard icon={BarChart3} title="Completion Rate" value="85%" />
            <StatCard icon={Book} title="Lessons Completed" value="24" />
          </div>

          {/* Code Converter */}
          <CodeConverter />

          {/* Recent Activity */}
          <div className="glass-panel p-8">
            <h2 className="text-xl font-bold mb-6">Recent Activity</h2>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center space-x-4 p-4 glass-panel">
                  <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                    <Code2 className="h-5 w-5 text-amber-500" />
                  </div>
                  <div>
                    <h3 className="font-medium">Completed Python Basics</h3>
                    <p className="text-sm text-gray-400">2 hours ago</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;