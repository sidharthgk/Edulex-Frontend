import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Code2, Menu } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <nav className="fixed w-full z-50 glass-panel">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <Code2 className="h-8 w-8 text-amber-500" />
            <span className="font-montserrat text-xl tracking-wider">CLLP</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <Link to="/features" className="hover:text-amber-500 transition-colors">Features</Link>
            <Link to="/pricing" className="hover:text-amber-500 transition-colors">Pricing</Link>
            <Link to="/login" className="btn-secondary">Login</Link>
            <Link to="/signup" className="btn-primary">Get Started</Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-300 hover:text-white"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="md:hidden glass-panel mt-2 mx-4 p-4 rounded-lg"
        >
          <div className="flex flex-col space-y-4">
            <Link to="/features" className="hover:text-amber-500 transition-colors">Features</Link>
            <Link to="/pricing" className="hover:text-amber-500 transition-colors">Pricing</Link>
            <Link to="/login" className="btn-secondary text-center">Login</Link>
            <Link to="/signup" className="btn-primary text-center">Get Started</Link>
          </div>
        </motion.div>
      )}
    </nav>
  );
};

export default Navbar;